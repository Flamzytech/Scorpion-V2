//base by DGXeon
//re-upload? recode? copy code? give credit ya :)
//YouTube: @DGXeon
//Instagram: unicorn_xeon13
//Telegram: t.me/xeonbotinc
//GitHub: @DGXeon
//WhatsApp: +916909137213
//want more free bot scripts? 
//subscribe to my youtube channel: https://youtube.com/@DGXeon

const fs = require('fs');
const chalk = require('chalk');

//owmner v card
global.ytname = "YT: Flamzytech" //ur yt chanel name
global.socialm = "Instagram: @Flamzytech" //ur github or insta name
global.location = "Nigeria" //ur location

//new
global.botname = 'Scorpion_V2' //ur bot name
global.ownernumber = ['2349065466353'] //ur owner number, dont add more than one
global.ownername = 'Flamzytech' //ur owner name
global.websitex = "https://youtube.com/@flamzytech?si=FjWps9CmfaQOUsol"
global.wagc = "https://whatsapp.com/channel/0029VaktEOFBPzjWIl8Bf219"
global.themeemoji = '🥷'
global.wm = "Flamzytech"
global.botscript = 'https://github.com/Flamzytech/scorpion-v2//script link
global.packname = "Sticker By Flamzytech"
global.author = " Flamzytech\n\n+2349065466353"
global.creator = "2349065466353@s.whatsapp.net"
global.xprefix = '.'
global.premium = ["2349065466353"] // Premium User

//bot sett
global.typemenu = 'v12' // menu type 'v1' => 'v12'
global.typereply = 'v4' // reply type 'v1' => 'v4'
global.autoblocknumber = '92' //set autoblock country code
global.antiforeignnumber = '91' //set anti foreign number country code

global.listv = ['•','●','■','✿','▲','➩','➢','➣','➤','✦','✧','△','❀','○','□','♤','♡','◇','♧','々','〆']
global.tempatDB = 'database.json'

global.limit = {
	free: 100,
	premium: 999,
	vip: 'VIP'
}

global.uang = {
	free: 10000,
	premium: 1000000,
	vip: 10000000
}

global.mess = {
	error: 'Error!',
	nsfw: 'Nsfw is disabled in this group, Please tell the admin to enable',
	done: 'Done'
}

global.bot = {
	limit: 0,
	uang: 0
}

global.game = {
	suit: {},
	menfes: {},
	tictactoe: {},
	kuismath: {},
	tebakbom: {},
}

//~~~~~~~~~~~~~~~< PROCESS >~~~~~~~~~~~~~~~\\

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});