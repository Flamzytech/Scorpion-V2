{
	"name": "Scorpion Bot Multi Device "
}